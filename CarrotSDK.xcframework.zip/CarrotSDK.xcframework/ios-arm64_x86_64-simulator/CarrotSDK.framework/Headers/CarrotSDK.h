//
//  CarrotSDK.h
//  CarrotSDK
//
//  Created by Ilya Chadov on 30/01/2019.
//  Copyright © 2019 Carrot quest. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for CarrotSDK.
FOUNDATION_EXPORT double CarrotSDKVersionNumber;

//! Project version string for CarrotSDK.
FOUNDATION_EXPORT const unsigned char CarrotSDKVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <CarrotSDK/PublicHeader.h>


