//
//  DashlySDK.h
//  DashlySDK
//
//  Created by Ilya Chadov on 27.12.2019.
//  Copyright © 2019 Ilya Chadov. All rights reserved.
//

#import <Foundation/Foundation.h>

//! Project version number for DashlySDK.
FOUNDATION_EXPORT double DashlySDKVersionNumber;

//! Project version string for DashlySDK.
FOUNDATION_EXPORT const unsigned char DashlySDKVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <DashlySDK/PublicHeader.h>


