//
//  CarrotLib.h
//  CarrotLib
//
//  Created by Ilya Chadov on 07/02/2019.
//  Copyright © 2019 Carrot quest. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for CarrotLib.
FOUNDATION_EXPORT double CarrotLibVersionNumber;

//! Project version string for CarrotLib.
FOUNDATION_EXPORT const unsigned char CarrotLibVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <CarrotLib/PublicHeader.h>


