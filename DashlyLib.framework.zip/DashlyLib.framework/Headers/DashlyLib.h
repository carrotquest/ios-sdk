//
//  DashlyLib.h
//  DashlyLib
//
//  Created by Ilya Chadov on 09.01.2020.
//  Copyright © 2020 Ilya Chadov. All rights reserved.
//

#import <Foundation/Foundation.h>

//! Project version number for DashlyLib.
FOUNDATION_EXPORT double DashlyLibVersionNumber;

//! Project version string for DashlyLib.
FOUNDATION_EXPORT const unsigned char DashlyLibVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <DashlyLib/PublicHeader.h>


